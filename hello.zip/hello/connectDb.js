import mongoose from "mongoose";
const dbConnection = async(url) => {
    await mongoose.connect(url);
}

export default dbConnection;